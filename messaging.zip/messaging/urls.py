from django.urls import path
from . import views

from .views import (
    inbox,
    sent_messages,
    send_message,
    message_detail,
)


urlpatterns = [
    path("", views.inbox, name="inbox"),
    path("sent/", views.sent_messages, name="sent_messages"),
    path("send/", views.send_message, name="send_message"),
    path("<int:pk>/", views.message_detail, name="message_detail"),
    path("delete/<int:pk>/", views.delete_message, name="delete_message"),
]
