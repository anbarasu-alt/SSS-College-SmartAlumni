from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .forms import MessageForm
from .models import Message


@login_required
def inbox(request):
    messages_list = Message.objects.filter(receiver=request.user).order_by("-sent_at")
    return render(request, "messaging/inbox.html", {"messages": messages_list})


@login_required
def sent_messages(request):
    messages_list = Message.objects.filter(sender=request.user).order_by("-sent_at")
    return render(request, "messaging/sent.html", {"messages": messages_list})


@login_required
def send_message(request):
    if request.method == "POST":
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.save()
            messages.success(request, "Message sent successfully.")
            return redirect("inbox")
    else:
        form = MessageForm()
    return render(request, "messaging/send.html", {"form": form})


@login_required
def message_detail(request, pk):
    message = get_object_or_404(Message, pk=pk)

    if request.user not in (message.sender, message.receiver):
        messages.error(request, "You do not have permission to view this message.")
        return redirect("inbox")

    if message.receiver == request.user and not message.is_read:
        message.is_read = True
        message.save(update_fields=["is_read"])

    return render(request, "messaging/detail.html", {"message": message})


@login_required
def delete_message(request, pk):
    if request.method != "POST":
        messages.error(request, "Invalid request method.")
        return redirect("inbox")

    message = get_object_or_404(Message, pk=pk)

    if request.user not in (message.sender, message.receiver):
        messages.error(request, "Permission denied.")
        return redirect("inbox")

    message.delete()
    messages.success(request, "Message deleted successfully.")
    return redirect("inbox")
