from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render
from accounts.models import User


@login_required
def alumni_list(request):
    """Dynamic alumni directory based on registered User accounts."""
    search = request.GET.get("search", "").strip()
    alumni = User.objects.filter(role="ALUMNI", is_active=True).order_by(
        "first_name", "last_name", "username"
    )

    if search:
        alumni = alumni.filter(
            Q(first_name__icontains=search)
            | Q(last_name__icontains=search)
            | Q(username__icontains=search)
            | Q(email__icontains=search)
            | Q(department__icontains=search)
            | Q(company__icontains=search)
            | Q(designation__icontains=search)
            | Q(skills__icontains=search)
            | Q(bio__icontains=search)
        )

    return render(request, "alumni/alumni_list.html", {
        "alumni": alumni,
        "search": search,
        "total_count": alumni.count(),
    })
