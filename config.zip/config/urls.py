from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [

    # Admin
    path("admin/", admin.site.urls),

    # Accounts
    path("accounts/", include("accounts.urls")),

    # Jobs
    path("jobs/", include("jobs.urls")),

    # Alumni
    path("alumni/", include("alumni.urls")),

    # Students
    path("students/", include("students.urls")),

    # Dashboard
    path("dashboard/", include("dashboard.urls")),

    # Events
    path("events/", include("events.urls")),

    # Mentorship
    path("mentorship/", include("mentorship.urls")),

    # Messaging
    path("inbox/", include("messaging.urls")),

    # Forum
    path("post_list/", include("forum.urls")),

    # Home
    path("", RedirectView.as_view(url="/dashboard/", permanent=False)),

    path("notifications/", include("notifications.urls")),
]
if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT
    )